# virtual_wallet
Un proyecto de curso, con opciones basicas de una cartera virtual(por consola).
